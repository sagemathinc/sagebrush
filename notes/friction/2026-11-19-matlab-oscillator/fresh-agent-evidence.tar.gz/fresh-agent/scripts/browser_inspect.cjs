const {chromium} = require('../runtime/node_modules/playwright-core');
const fs = require('fs');
(async()=>{
 const context=await chromium.launchPersistentContext(process.cwd()+'/runtime/browser-profile',{executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox'],timeout:20000});
 const page=await context.newPage();
 page.setDefaultTimeout(15000);
 const url=fs.readFileSync('evidence/notebook-server.stdout','utf8').match(/http:\/\/127[^\s]+/)[0];
 await page.goto(url,{waitUntil:'domcontentloaded',timeout:20000});
 await page.waitForTimeout(1500);
 fs.writeFileSync('evidence/notebook-ui.txt',await page.locator('body').innerText());
 fs.writeFileSync('evidence/notebook-elements.json',JSON.stringify(await page.locator('button,input,select,textarea,[contenteditable]').evaluateAll(es=>es.map(e=>({tag:e.tagName,text:e.innerText,title:e.title,placeholder:e.placeholder,aria:e.getAttribute('aria-label'),class:e.className,role:e.getAttribute('role')}))),null,2));
 await page.screenshot({path:'evidence/notebook-initial.png',fullPage:true});
 await context.close();
})().catch(e=>{console.error(e);process.exitCode=1});
