"""Independent host-side checks of the exported, machine-readable artifacts."""
import csv,json,math,pathlib
root=pathlib.Path(__file__).resolve().parent.parent
engines=['sagebrush','octave']; truth=dict(amplitude=2.4,decay_rate=.18,angular_frequency=4.7,phase=.65)
results={};tables={}; checks={}
for engine in engines:
 r=json.loads((root/'evidence'/f'{engine}-result.json').read_text(),parse_constant=lambda s: (_ for _ in ()).throw(ValueError(s)))
 rows=list(csv.DictReader((root/'evidence'/f'{engine}-trajectory.csv').open()))
 a={k:[float(row[k]) for row in rows] for k in rows[0]}
 assert len(rows)==r['n']==401
 assert all(math.isfinite(x) for v in a.values() for x in v)
 assert all(x<y for x,y in zip(a['t'],a['t'][1:]))
 sse=sum((f-x)**2 for f,x in zip(a['fitted'],a['observed']))
 ode=max(abs(f-y) for f,y in zip(a['fitted'],a['ode']))
 assert abs(sse-r['sse'])<1e-12
 assert abs(math.sqrt(sse/r['n'])-r['rmse'])<1e-12
 assert abs(ode-r['ode_max_abs_error'])<1e-12
 assert ode<1e-6 and r['rmse']<.03 and all(v==1 for v in r['exitflags'])
 # Independently reconstruct the synthetic data from the specified model/noise.
 clean=[2.4*math.exp(-.18*t)*math.cos(4.7*t+.65) for t in a['t']]
 observed=[c+.025*math.sin(17.3*t+.2)+.020*math.cos(29.1*t-.7)+.010*math.sin(43*t+1.1) for c,t in zip(clean,a['t'])]
 assert max(abs(x-y) for x,y in zip(clean,a['clean']))<1e-12
 assert max(abs(x-y) for x,y in zip(observed,a['observed']))<1e-12
 results[engine]=r;tables[engine]=a
 checks[engine]={'json_parsed':True,'csv_rows':len(rows),'finite':True,'sse_recomputed':sse,'ode_max_error_recomputed':ode,'parameter_errors_vs_truth':{k:r[k]-v for k,v in truth.items()}}
delta={k:abs(results['sagebrush'][k]-results['octave'][k]) for k in truth}
assert max(delta.values())<1e-7
trajectory_delta={k:max(abs(x-y) for x,y in zip(tables['sagebrush'][k],tables['octave'][k])) for k in tables['sagebrush']}
assert trajectory_delta['fitted']<1e-7 and trajectory_delta['ode']<1e-7
out={'passed':True,'truth':truth,'checks':checks,'parameter_absolute_differences_between_engines':delta,'trajectory_max_absolute_differences':trajectory_delta}
(root/'evidence/validation.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
