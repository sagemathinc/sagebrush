const {chromium} = require('../runtime/node_modules/playwright-core');
const fs = require('fs');
(async()=>{
 const context=await chromium.launchPersistentContext(process.cwd()+'/runtime/browser-profile',{executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox'],timeout:20000});
 try {
 const page=await context.newPage(); page.setDefaultTimeout(12000);
 page.on('console',msg=>console.log('BROWSER',msg.type(),msg.text()));
 page.on('response',async r=>{if(r.status()>=400) console.log('HTTPERROR',r.status(),r.url(),(await r.text()).slice(0,500));});
 page.on('pageerror',e=>console.log('PAGEERROR',e.toString()));
 const url=fs.readFileSync('evidence/notebook-server.stdout','utf8').match(/http:\/\/127[^\s]+/)[0];
 await page.goto(url,{waitUntil:'domcontentloaded',timeout:20000});
 page.on('dialog',async d=>{console.log('DIALOG',d.type(),d.message());await d.accept('oscillator-stop-test')});
 await page.getByRole('button',{name:'New notebook',exact:true}).click();
 await page.getByLabel('Language',{exact:true}).selectOption({label:'MATLAB'});
 await page.getByLabel('Cell 1 code',{exact:true}).fill(fs.readFileSync('scripts/stop_setup.m','utf8'));
 await page.getByLabel('Run cell 1',{exact:true}).click();
 await page.waitForFunction(()=>document.body.innerText.includes('BEFORE sentinel=271828 A=2.40430982772'),{},{timeout:15000});
 fs.writeFileSync('evidence/stop-before.txt',await page.locator('body').innerText());
 await page.getByTitle('Add a code cell at the end (B in command mode adds one below)',{exact:true}).click();
 await page.getByLabel('Cell 2 code',{exact:true}).fill(fs.readFileSync('scripts/stop_long.m','utf8'));
 await page.getByLabel('Run cell 2',{exact:true}).click();
 await page.getByRole('button',{name:'■ Stop',exact:true}).waitFor({state:'visible',timeout:10000});
 await page.waitForTimeout(1200);
 fs.writeFileSync('evidence/stop-running.txt',await page.locator('body').innerText());
 const began=Date.now();
 await page.getByRole('button',{name:'■ Stop',exact:true}).click();
 await page.waitForFunction(()=>document.body.innerText.includes('KeyboardInterrupt'),{},{timeout:12000});
 const latency=Date.now()-began;
 fs.writeFileSync('evidence/stop-interrupted.txt',await page.locator('body').innerText());
 await page.screenshot({path:'evidence/stop-interrupted.png',fullPage:true});
 await page.getByTitle('Add a code cell at the end (B in command mode adds one below)',{exact:true}).click();
 await page.getByLabel('Cell 3 code',{exact:true}).fill(fs.readFileSync('scripts/stop_recover.m','utf8'));
 await page.getByLabel('Run cell 3',{exact:true}).click();
 await page.waitForFunction(()=>document.body.innerText.includes('AFTER sentinel=271828 A=2.40430982772 answer=42'),{},{timeout:15000});
 const body=await page.locator('body').innerText();
 fs.writeFileSync('evidence/stop-after.txt',body);
 fs.writeFileSync('evidence/stop-result.json',JSON.stringify({interface:'npm notebook UI',language:'MATLAB',stop_clicked:true,keyboard_interrupt:true,stop_latency_ms:latency,prior_scalar_preserved:true,prior_vector_preserved:true,new_calculation:42,url:page.url()},null,2)+'\n');
 await page.screenshot({path:'evidence/stop-after.png',fullPage:true});
 // Save the visible test document through its normal download action.
 await page.getByRole('button',{name:'File ▾',exact:true}).click();
 await page.getByRole('menuitem',{name:'Download ▸',exact:true}).hover();
 const downloadPromise=page.waitForEvent('download',{timeout:10000});
 await page.getByRole('menuitem',{name:'.ipynb',exact:true}).click();
 const download=await downloadPromise;await download.saveAs('evidence/stop-test.ipynb');
 console.log('STOP_TEST_PASSED',latency);
 } catch(e) {const page=context.pages().slice(-1)[0]; fs.writeFileSync('evidence/stop-failure-ui.txt',await page.locator('body').innerText()); await page.screenshot({path:'evidence/stop-failure.png',fullPage:true}); throw e;} finally {await context.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
