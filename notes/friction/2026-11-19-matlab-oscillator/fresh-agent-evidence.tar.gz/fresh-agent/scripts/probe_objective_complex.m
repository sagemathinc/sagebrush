try
 o=optimset('Display','off','FunValCheck','on'); [q,v]=fminsearch(@(q) 1i,1,o);
 fprintf('PROBE_STATUS=success\n');
catch err
 fprintf('PROBE_STATUS=error\n');
 fprintf('ERROR_ID=%s\n',err.identifier);
 fprintf('ERROR_MESSAGE=%s\n',err.message);
end
