| Probe | Sagebrush | Octave | Rejection parity |
|---|---|---|---|
| index_zero | error (`MATLAB:index:expected_positive_integer`) | error (`Octave:invalid-index`) | True |
| matrix_dimensions | error (`MATLAB:innerdim`) | error (`Octave:nonconformant-args`) | True |
| objective_nan | error (empty ID) | error (`fminsearch:isnan`) | True |
| objective_complex | error (empty ID) | error (`fminsearch:notreal`) | True |
| objective_vector | error (empty ID) | error (`Octave:nonconformant-args`) | True |
| ode_wrong_rhs | error (empty ID) | error (`Octave:nonconformant-args`) | True |
| ode_nonmonotonic_times | error (empty ID) | success | False |
| ode_negative_tolerance | error (empty ID) | error (`Octave:expected-positive`) | True |
| jsonencode | error (`MATLAB:UndefinedFunction`) | success | False |
