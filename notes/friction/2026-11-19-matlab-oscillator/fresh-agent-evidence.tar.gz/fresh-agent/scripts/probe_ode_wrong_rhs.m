try
 [t,y]=ode45(@(t,y) [y;y],[0 1],1);
 fprintf('PROBE_STATUS=success\n');
catch err
 fprintf('PROBE_STATUS=error\n');
 fprintf('ERROR_ID=%s\n',err.identifier);
 fprintf('ERROR_MESSAGE=%s\n',err.message);
end
