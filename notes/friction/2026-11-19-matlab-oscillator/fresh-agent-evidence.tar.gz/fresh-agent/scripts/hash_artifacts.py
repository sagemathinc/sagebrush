import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent.parent
manifest={}
for directory in ['scripts','evidence']:
 for p in sorted((root/directory).rglob('*')):
  if p.is_file() and p.name!='sha256-manifest.json':
   manifest[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['REPORT.md','FRICTION.md']:
 p=root/name;manifest[name]=hashlib.sha256(p.read_bytes()).hexdigest()
(root/'evidence/sha256-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
