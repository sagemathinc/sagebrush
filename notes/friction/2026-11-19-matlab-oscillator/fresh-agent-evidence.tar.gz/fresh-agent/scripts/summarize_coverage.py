import json,pathlib
r=pathlib.Path(__file__).resolve().parent.parent
probes=json.loads((r/'evidence/error-probes.json').read_text())
paired={}
for p in probes:paired.setdefault(p['case'],{})[p['engine']]=p
rows=[]
for case,eng in paired.items():
 a,b=eng['sagebrush'],eng['octave']
 rows.append({'case':case,'sagebrush_status':a['probe_status'],'sagebrush_identifier':a['error_id'],'octave_status':b['probe_status'],'octave_identifier':b['error_id'],'rejection_parity':a['probe_status']==b['probe_status'],'identifier_literal_parity':a['error_id']==b['error_id'] if a['probe_status']==b['probe_status']=='error' else None})
out={'runtime':'npm sagebrush@0.10.1','reference':'GNU Octave 11.1.0; proprietary MATLAB unavailable/not used','hits':['MATLAB elementwise arithmetic, vectors, transposes, indexing, anonymous closures, loops and if','fminsearch, optimset, four-output solver interface, three convergent starts','positive-parameter log transform, mod phase wrapping','ode45 two-state system, odeset tolerances, requested output times','assert, exist, mean, sum, max, all, exp, sin, cos, log, sqrt','fopen/fprintf/fclose numeric JSON and CSV export','MATLAB try/catch err.identifier and err.message (identifiers partially populated)','notebook UI Stop interrupts while loop and preserves prior scalar/vector; later arithmetic works','documentation search JSON including coverage statuses and alternatives'], 'misses':['MATLAB jsonencode absent','Several numerical error identifiers empty','CLI has no advertised general --json execution/error envelope; uncaught errors observed as text','Notebook interruption is saved as stderr stream, not structured error metadata','Local notebook auxiliary requests include 404/403','MATLAB proprietary reference parity unavailable'], 'not_tested':['GUI plot export','MAT-file round trip','confidence intervals/statistical noise inference','Stop during native/WASM numerical kernels or memory-intensive allocations','Interrupted computation rollback/atomicity','Proprietary MATLAB identifiers and exact error text','general JSON serialization including strings and nonfinite values'], 'error_probes':rows}
(r/'evidence/coverage.json').write_text(json.dumps(out,indent=2)+'\n')
print('| Probe | Sagebrush | Octave | Rejection parity |')
print('|---|---|---|---|')
for x in rows:
 def fmt(status,identifier):return status+(' (`'+identifier+'`)' if identifier else (' (empty ID)' if status=='error' else ''))
 print('| '+x['case']+' | '+fmt(x['sagebrush_status'],x['sagebrush_identifier'])+' | '+fmt(x['octave_status'],x['octave_identifier'])+' | '+str(x['rejection_parity'])+' |')
