try
    a = [1 2];
    b = a(0);
    fprintf('UNEXPECTED_SUCCESS\n');
catch err
    fprintf('ERROR_ID=%s\n',err.identifier);
    fprintf('ERROR_MESSAGE=%s\n',err.message);
end
