fprintf('AFTER sentinel=%d A=%.12g answer=%d spin=%d\n',sentinel,prior_fit(1),6*7,spin);
assert(sentinel == 271828);
expected_fit = [2.4043098277195907 0.1804888025040971 4.7002533786994327 0.64908323841483773];
assert(all(abs(prior_fit-expected_fit) < 1e-12));
