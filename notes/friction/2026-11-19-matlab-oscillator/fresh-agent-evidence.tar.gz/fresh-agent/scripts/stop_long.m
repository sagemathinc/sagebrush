spin = 0;
while true
    spin = spin + 1;
end
