try
 s=jsonencode(struct('x',1)); fprintf('%s\n',s);
 fprintf('PROBE_STATUS=success\n');
catch err
 fprintf('PROBE_STATUS=error\n');
 fprintf('ERROR_ID=%s\n',err.identifier);
 fprintf('ERROR_MESSAGE=%s\n',err.message);
end
