a = [1; 2; 3];
fid = fopen('evidence/smoke.csv', 'w');
fprintf(fid, 'x,y\n');
fprintf(fid, '%g,%g\n', [a a.^2]');
fclose(fid);
fprintf('{"sum":%.17g}\n', sum(a));
