try
 b=[1 2]*[1 2];
 fprintf('PROBE_STATUS=success\n');
catch err
 fprintf('PROBE_STATUS=error\n');
 fprintf('ERROR_ID=%s\n',err.identifier);
 fprintf('ERROR_MESSAGE=%s\n',err.message);
end
