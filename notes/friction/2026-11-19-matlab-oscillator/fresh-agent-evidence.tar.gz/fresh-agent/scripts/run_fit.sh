#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
timeout 120s ./runtime/node_modules/.bin/sagebrush --matlab scripts/oscillator_fit.m > evidence/sagebrush-fit.stdout 2> evidence/sagebrush-fit.stderr
timeout 120s octave --no-gui --quiet --eval "prefix=fullfile(pwd,'evidence','octave'); run('scripts/oscillator_fit.m');" > evidence/octave-fit-retry.stdout 2> evidence/octave-fit-retry.stderr
timeout 20s python scripts/validate_results.py > evidence/validation.stdout 2> evidence/validation.stderr
