import hashlib,json,pathlib,socket,datetime
root=pathlib.Path(__file__).resolve().parent.parent
stop=json.loads((root/'evidence/stop-result.json').read_text())
nb=json.loads((root/'evidence/stop-test.ipynb').read_text())
assert nb['metadata']['language_info']['name']=='matlab'
assert len(nb['cells'])==3
text=lambda c: ''.join(''.join(o.get('text',[])) for o in c.get('outputs',[]))
assert 'BEFORE sentinel=271828' in text(nb['cells'][0])
assert 'KeyboardInterrupt' in text(nb['cells'][1])
assert 'AFTER sentinel=271828 A=2.40430982772 answer=42' in text(nb['cells'][2])
assert 'assert(all(abs(prior_fit-expected_fit)' in ''.join(nb['cells'][2]['source'])
assert (root/'evidence/stop-browser-passed.exit').read_text().strip()=='0'
assert json.loads((root/'evidence/validation.json').read_text())['passed']
try:
 with socket.create_connection(('127.0.0.1',8877),timeout=2):closed=False
except OSError:closed=True
assert closed, 'Run-owned notebook port still open'
audit={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'numerical_validation_passed':True,'native_stop_notebook_verified':True,'all_four_prior_vector_components_asserted':True,'stop_latency_ms':stop['stop_latency_ms'],'final_browser_harness_exit':0,'notebook_server_timeout_exit':124,'notebook_port_closed':closed,'reference':'GNU Octave 11.1.0','scope':'scratch-local files, public npm release; no product edits'}
(root/'evidence/final-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
coverage=json.loads((root/'evidence/coverage.json').read_text())
coverage_hit='Reactive notebook blocks downstream reads from interrupted cell; prior-only recovery passes'
if coverage_hit not in coverage['hits']: coverage['hits'].append(coverage_hit)
(root/'evidence/coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')
print(json.dumps(audit,indent=2))
