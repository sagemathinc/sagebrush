try
 o=optimset('Display','off','MaxIter',3); [q,v]=fminsearch(@(q) [q q],1,o);
 fprintf('PROBE_STATUS=success\n');
catch err
 fprintf('PROBE_STATUS=error\n');
 fprintf('ERROR_ID=%s\n',err.identifier);
 fprintf('ERROR_MESSAGE=%s\n',err.message);
end
