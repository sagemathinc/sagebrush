sentinel = 271828;
prior_fit = [2.4043098277195907 0.1804888025040971 4.7002533786994327 0.64908323841483773];
fprintf('BEFORE sentinel=%d A=%.12g\n',sentinel,prior_fit(1));
