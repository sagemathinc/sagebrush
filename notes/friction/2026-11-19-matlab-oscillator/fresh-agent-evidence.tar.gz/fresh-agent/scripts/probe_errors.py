"""Run identical MATLAB invalid-input probes; preserve raw streams and IDs."""
import json, pathlib, subprocess, time
root=pathlib.Path.cwd()
cases={
 'index_zero':"a=[1 2]; b=a(0);",
 'matrix_dimensions':"b=[1 2]*[1 2];",
 'objective_nan':"o=optimset('Display','off','FunValCheck','on'); [q,v]=fminsearch(@(q) NaN,1,o);",
 'objective_complex':"o=optimset('Display','off','FunValCheck','on'); [q,v]=fminsearch(@(q) 1i,1,o);",
 'objective_vector':"o=optimset('Display','off','MaxIter',3); [q,v]=fminsearch(@(q) [q q],1,o);",
 'ode_wrong_rhs':"[t,y]=ode45(@(t,y) [y;y],[0 1],1);",
 'ode_nonmonotonic_times':"[t,y]=ode45(@(t,y) -y,[0 1 0.5],1);",
 'ode_negative_tolerance':"o=odeset('RelTol',-1); [t,y]=ode45(@(t,y) -y,[0 1],1,o);",
 'jsonencode':"s=jsonencode(struct('x',1)); fprintf('%s\\n',s);",
}
results=[]
for name,code in cases.items():
 path=root/'scripts'/('probe_'+name+'.m')
 path.write_text("try\n "+code+"\n fprintf('PROBE_STATUS=success\\n');\ncatch err\n fprintf('PROBE_STATUS=error\\n');\n fprintf('ERROR_ID=%s\\n',err.identifier);\n fprintf('ERROR_MESSAGE=%s\\n',err.message);\nend\n")
 for engine,cmd in [('sagebrush',[str(root/'runtime/node_modules/.bin/sagebrush'),'--matlab',str(path)]),('octave',['octave','--no-gui','--quiet',str(path)])]:
  start=time.monotonic()
  try:
   p=subprocess.run(cmd,cwd=root,capture_output=True,text=True,timeout=20)
   out,err,rc=p.stdout,p.stderr,p.returncode
  except subprocess.TimeoutExpired as e:
   out=e.stdout or b'';err=e.stderr or b'';rc='timeout'
   if isinstance(out,bytes):out=out.decode(errors='replace')
   if isinstance(err,bytes):err=err.decode(errors='replace')
  stem=root/'evidence'/f'{engine}-{name}'
  stem.with_suffix('.stdout').write_text(out);stem.with_suffix('.stderr').write_text(err)
  record=dict(case=name,engine=engine,command=cmd,returncode=rc,elapsed_seconds=time.monotonic()-start,stdout=out,stderr=err)
  for key in ['PROBE_STATUS','ERROR_ID','ERROR_MESSAGE']:
   values=[line.split('=',1)[1] for line in out.splitlines() if line.startswith(key+'=')]
   record[key.lower()]=values[0] if values else None
  results.append(record)
  print(name,engine,rc,record['probe_status'],record['error_id'],flush=True)
(root/'evidence/error-probes.json').write_text(json.dumps(results,indent=2)+'\n')
# Also retain an uncaught CLI failure, to test process-level machine readability.
for engine,cmd in [('sagebrush',[str(root/'runtime/node_modules/.bin/sagebrush'),'--matlab','-c','a=[1 2]; b=a(0);']),('octave',['octave','--no-gui','--quiet','--eval','a=[1 2]; b=a(0);'])]:
 p=subprocess.run(cmd,cwd=root,capture_output=True,text=True,timeout=20)
 (root/'evidence'/f'{engine}-uncaught.json').write_text(json.dumps(dict(command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr),indent=2)+'\n')
